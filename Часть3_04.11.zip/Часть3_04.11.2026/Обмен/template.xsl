﻿<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://w3.org">
<xsl:template match="/">
  <html>
  <head>
    <title>Отчет XSLT</title>
    <style>body { font-family: Arial; margin: 20px; } table { border-collapse: collapse; width: 50%; } th, td { border: 1px solid #333; padding: 8px; text-align: left; } th { background-color: #1c355e; color: white; }</style>
  </head>
  <body>
    <h2>Данные, трансформированные через XSLT</h2>
    <table>
      <tr><th>Код товара</th><th>Наименование номенклатуры</th></tr>
      <xsl:for-each select="Корневой/Элемент">
      <tr>
        <td><xsl:value-of select="@Код"/></td>
        <td><xsl:value-of select="@Наименование"/></td>
      </tr>
      </xsl:for-each>
    </table>
  </body>
  </html>
</xsl:template>
</xsl:stylesheet>
